@extends('layouts.master')
@section('title')
ألاسرة المهيئة 
@stop
@section('css')
<!-- Internal Data table css -->
<link href="{{ URL::asset('assets/plugins/datatable/css/dataTables.bootstrap4.min.css') }}" rel="stylesheet" />
<link href="{{ URL::asset('assets/plugins/datatable/css/buttons.bootstrap4.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/datatable/css/responsive.bootstrap4.min.css') }}" rel="stylesheet" />
<link href="{{ URL::asset('assets/plugins/datatable/css/jquery.dataTables.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/datatable/css/responsive.dataTables.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css') }}" rel="stylesheet">
<!--Internal   Notify -->
<link href="{{ URL::asset('assets/plugins/notify/css/notifIt.css') }}" rel="stylesheet" />
<!-- Custom CSS -->
<link href="{{ URL::asset('assets/css/print.css') }}" rel="stylesheet" />
<link href="{{ URL::asset('assets/css/private-wings.css') }}" rel="stylesheet" />
@endsection
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">                <div class="card-header">
                    <div class="text-center mb-3">
                        <h2 class="mb-2">جمهورية العراق</h2>
                        <h3 class="mb-2">وزارة الصحة</h3>
                        <h2 class="invoice-title">وصل حساب الجناح الخاص</h2>
                        <div class="invoice-number mt-3">
                            <span>رقم قائمة الحساب: {{ $privateWing->file_number }}</span>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <strong>المستشفى:</strong>
                            <p>{{ $privateWing->hospital }}</p>
                        </div>
                        <div class="col-md-4">
                            <strong>دائرة صحة:</strong>
                            <p>{{ $privateWing->health_department }}</p>
                        </div>
                        <div class="col-md-4">
                            <strong>اسم المريض:</strong>
                            <p>{{ $privateWing->patient_name }}</p>
                        </div>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <strong>تاريخ تنظيم القائمة:</strong>
                            <p>{{ $privateWing->created_at ? $privateWing->created_at->format('Y-m-d') : '' }}</p>
                        </div>
                        <div class="col-md-4">
                            <strong>تاريخ الدخول:</strong>
                            <p>{{ $privateWing->entry_date ? $privateWing->entry_date->format('Y-m-d') : '' }}</p>
                        </div>
                        <div class="col-md-4">
                            <strong>تاريخ الخروج:</strong>
                            <p>{{ $privateWing->exit_date ? $privateWing->exit_date->format('Y-m-d') : '' }}</p>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-4">
                            <strong>رقم قائمة الحساب :</strong>
                            <p>{{ $privateWing->file_number }}</p>
                        </div>
                        <div class="col-md-4">
                            <strong>الرقم الإحصائي:</strong>
                            <p>{{ $privateWing->statistical_number }}</p>
                        </div>
                        <div class="col-md-4">
                            <strong>عدد الأيام:</strong>
                            <p>{{ $privateWing->days_count }}</p>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <strong>تاريخ الدخول:</strong>
                            <p>{{ $privateWing->entry_date }}</p>
                        </div>
                        <div class="col-md-6">
                            <strong>تاريخ الخروج:</strong>
                            <p>{{ $privateWing->exit_date }}</p>
                        </div>
                    </div>

                             <h4 class="mt-4 mb-3">الخدمات المقدمة</h4>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>اسم الخدمة</th>
                                    <th>الأجور</th>
                                    <th>احتساب الأيام</th>
                                    <th>المبلغ الإجمالي</th>
                                </tr>
                            </thead>                            <tbody>
                                @foreach($services as $service)
                                <tr>
                                    <td>{{ $service->service_name }}</td>
                                    <td>
                                        {{ number_format($service->service_fee, 2) }}
                                        <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert($service->service_fee) }})</span>
                                    </td>
                                    <td>{{ $service->is_daily ? 'نعم' : 'لا' }}</td>
                                    <td>
                                        {{ number_format($service->total_amount, 2) }}
                                        <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert($service->total_amount) }})</span>
                                    </td>
                                </tr>
                                @endforeach
                                <tr>
                                    <td colspan="3" class="text-left"><strong>المجموع الكلي:</strong></td>
                                    <td>
                                        <strong>{{ number_format($privateWing->total_amount, 2) }} د.ع</strong>
                                        <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert($privateWing->total_amount) }})</span>
                                    </td>
                                </tr>                            </tbody>
                        </table>
                    </div>

                    <!-- جدول وصولات التأمين -->
                    <div class="card mt-4">
                        <div class="card-header bg-gradient-success">
                            <h4 class="mb-0 text-white"><i class="fas fa-receipt"></i> وصولات التأمين</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>رقم الوصل</th>
                                            <th>المبلغ</th>
                                            <th>تاريخ الوصل</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($privateWing->receipts as $index => $receipt)
                                        <tr>
                                            <td>{{ $index + 1 }}</td>
                                            <td>{{ $receipt->receipt_number }}</td>
                                            <td>
                                                {{ number_format($receipt->amount, 2) }} د.ع
                                                <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert($receipt->amount) }})</span>
                                            </td>
                                            <td>{{ $receipt->receipt_date->format('Y-m-d') }}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                    <tfoot>
                                        <tr class="table-info">
                                            <td colspan="2" class="text-left"><strong>إجمالي المبلغ المودع:</strong></td>
                                            <td colspan="2">
                                                <strong>{{ number_format($privateWing->deposit_amount, 2) }} د.ع</strong>
                                                <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert($privateWing->deposit_amount) }})</span>
                                            </td>
                                        </tr>
                                        <tr class="table-primary">
                                            <td colspan="2" class="text-left"><strong>المبلغ المتبقي:</strong></td>
                                            <td colspan="2">
                                                @php
                                                    $remaining = $privateWing->total_amount - $privateWing->deposit_amount;
                                                @endphp
                                                <strong class="{{ $remaining > 0 ? 'text-danger' : 'text-success' }}">
                                                    {{ number_format(abs($remaining), 2) }} د.ع {{ $remaining > 0 ? '(مدين)' : '(دائن)' }}
                                                </strong>
                                                <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert(abs($remaining)) }})</span>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>

                    <hr>
                    
                    <div class="row mt-4 print-section">
                        <div class="col-md-4">
                            <p><strong>توقيع المحاسب</strong></p>
                        </div>
                        <div class="col-md-4">
                            <p><strong>توقيع مدير المستشفى</strong></p>
                        </div>
                        <div class="col-md-4">
                            <p><strong>الختم</strong></p>
                           
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-12 text-center">
                            <button onclick="window.print()" class="btn btn-primary no-print">طباعة</button>
                            <a href="{{ route('private-wings.index') }}" class="btn btn-secondary no-print">رجوع</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
