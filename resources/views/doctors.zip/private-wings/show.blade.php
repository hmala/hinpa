@extends('layouts.master')
@section('title')
ألاسرة المهيئة 
@stop
@section('css')
<!-- Internal Data table css -->
<link href="{{ URL::asset('assets/plugins/datatable/css/dataTables.bootstrap4.min.css') }}" rel="stylesheet" />
<link href="{{ URL::asset('assets/plugins/datatable/css/buttons.bootstrap4.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/datatable/css/responsive.bootstrap4.min.css') }}" rel="stylesheet" />
<link href="{{ URL::asset('assets/plugins/datatable/css/jquery.dataTables.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/datatable/css/responsive.dataTables.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/plugins/select2/css/select2.min.css') }}" rel="stylesheet">
<!--Internal   Notify -->
<link href="{{ URL::asset('assets/plugins/notify/css/notifIt.css') }}" rel="stylesheet" />
<!-- Custom CSS -->
<link href="{{ URL::asset('assets/css/print.css') }}" rel="stylesheet" />
<link href="{{ URL::asset('assets/css/private-wings.css') }}" rel="stylesheet" />
@endsection
@section('content')
<div class="container py-4 invoice-bg" style="background: #f7f7fa; min-height: 100vh;">
    <div class="row justify-content-center">
        <div class="col-lg-9 col-md-11">
            <div class="card invoice-card border border-dark shadow-lg rounded-lg">
                <div class="card-header invoice-header bg-white text-center border-bottom border-dark">
                    <div class="mb-2">
                        <h2 class="mb-1 font-weight-bold text-dark" style="letter-spacing:2px;">جمهورية العراق</h2>
                        <h3 class="mb-1 text-dark">وزارة الصحة</h3>
                        <h2 class="invoice-title display-5 text-primary">فاتورة حساب الجناح الخاص</h2>
                        
                    </div>
                </div>

                <div class="card-body">
                    <!-- بيانات المريض والمستشفى -->
                    <div class="card mb-4 border-info">
                        <div class="card-header bg-info text-white text-center font-weight-bold">بيانات المريض والمستشفى</div>
                        <div class="card-body p-2">
                            <div class="table-responsive">
                                <table class="table table-bordered mb-0">
                                    <tbody>
                                        <tr>
                                            <th>المستشفى</th>
                                            <td>{{ $privateWing->hospital }}</td>
                                            <th>دائرة الصحة</th>
                                            <td>{{ $privateWing->health_department }}</td>
                                        </tr>
                                        <tr>
                                            <th>اسم المريض</th>
                                            <td>{{ $privateWing->patient_name }}</td>
                                            <th>رقم قائمة الحساب</th>
                                            <td>{{ $privateWing->file_number }}</td>
                                      
                                            <th>الرقم الإحصائي</th>
                                            <td>{{ $privateWing->statistical_number }}</td>
                                            <th>رقم الطبلة</th>
                                            <td>{{ $privateWing->table_number }}</td>
                                      
                                        </tr>
                                       
                                        <tr>
                                                                                        <th>جنسية المريض</th>
                                            <td>{{ $privateWing->patient_nationality }}</td>

                                            <th>عدد الأيام</th>
                                            <td>{{ $privateWing->days_count }}</td>
                                            <th>تاريخ تنظيم القائمة</th>
                                            <td>{{ $privateWing->created_at ? $privateWing->created_at->format('Y-m-d') : '' }}</td>
                                        </tr>
                                        <tr>
                                            <th>مشمول بالضمان</th>
                                            <td colspan="3">
                                                @if($privateWing->is_insured)
                                                    <span class="badge badge-success">نعم</span>
                                                @else
                                                    <span class="badge badge-danger">لا</span>
                                                @endif
                                            </td>
                                            <th>تاريخ الدخول</th>
                                            <td>{{ $privateWing->entry_date ? $privateWing->entry_date->format('Y-m-d') : '' }}</td>
                                            <th>تاريخ الخروج</th>
                                            <td>{{ $privateWing->exit_date ? $privateWing->exit_date->format('Y-m-d') : '' }}</td>
                                        </tr>
                                     
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- الخدمات المقدمة -->
                    <div class="card mb-4 border-primary">
                        <div class="card-header bg-primary text-white text-center font-weight-bold">الخدمات المقدمة</div>
                        <div class="card-body p-2">
                            <div class="table-responsive">
                                <table id="services-table" class="table table-bordered mb-0">
                                    <thead>
                                        <tr>
                                            <th>اسم الخدمة</th>
                                            <th>الطبيب</th>
                                            <th>درجة العملية</th>
                                            <th>الأجور</th>
                                            <th>احتساب الأيام</th>
                                            <th>المبلغ الإجمالي</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($services as $service)
                                        <tr>
                                            <td>{{ $service->service_name }}</td>
                                            <td>{{ $service->doctor_name ?? '' }}</td>
                                            <td>{{ $service->operation_degree ?? '' }}</td>
                                            <td>{{ number_format($service->service_fee, 2) }}</td>
                                            <td>{{ $service->is_daily ? 'نعم' : 'لا' }}</td>
                                            <td>{{ number_format($service->total_amount, 2) }}</td>
                                        </tr>
                                        @endforeach
                                        <tr>
                                            <td colspan="3" class="text-left"><strong>المجموع الكلي:</strong></td>
                                            <td>
                                                <strong>{{ number_format($privateWing->total_amount, 2) }} د.ع</strong>
                                                <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert($privateWing->total_amount) }})</span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- جدول وصولات التأمين -->
                    <div class="card mt-4">
                        <div class="card-header bg-gradient-success">
                            <h4 class="mb-0 text-white"><i class="fas fa-receipt"></i> وصولات التأمين</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="receipts-table" class="table table-bordered" style="text-align: right">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>رقم الوصل</th>
                                            <th>المبلغ</th>
                                            <th>تاريخ الوصل</th>
                                            <th>نوع الدفع</th>
                                            <th>النسبة (%)</th>
                                            <th>الفائدة (د.ع)</th>
                                            <th>الإجمالي (د.ع)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($privateWing->receipts as $index => $receipt)
                                        <tr>
                                            <td>{{ $index + 1 }}</td>
                                            <td>{{ $receipt->receipt_number }}</td>
                                            <td>
                                                {{ number_format($receipt->amount, 2) }} د.ع
                                                <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert($receipt->amount) }})</span>
                                            </td>
                                            <td>{{ $receipt->receipt_date->format('Y-m-d') }}</td>
                                            <td>{{ $receipt->payment_type }}</td>
                                            <td>{{ number_format($receipt->interest_rate, 2) }}%</td>
                                            <td>{{ number_format($receipt->interest_amount, 2) }} د.ع</td>
                                            <td>
                                                <strong>{{ number_format($receipt->amount + $receipt->interest_amount, 2) }} د.ع</strong>
                                                <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert($receipt->amount + $receipt->interest_amount) }})</span>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                    <tfoot>
                                        <tr class="table-info">
                                            <td colspan="6" class="text-left"><strong>إجمالي المبلغ المودع:</strong></td>
                                            <td colspan="2">
                                                @php
                                                    $totalDeposits = $privateWing->receipts->sum(function($receipt) {
                                                        return $receipt->amount + $receipt->interest_amount;
                                                    });
                                                @endphp
                                                <strong>{{ number_format($totalDeposits, 2) }} د.ع</strong>
                                                <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert($totalDeposits) }})</span>
                                            </td>
                                        </tr>
                                        <tr class="table-primary">
                                            <td colspan="6" class="text-left"><strong>المبلغ المتبقي:</strong></td>
                                            <td colspan="2">
                                                @php
                                                    $remaining = $privateWing->total_amount - $totalDeposits;
                                                @endphp
                                                <strong class="{{ $remaining > 0 ? 'text-danger' : 'text-success' }}">
                                                    {{ number_format(abs($remaining), 2) }} د.ع {{ $remaining > 0 ? '(مدين)' : '(دائن)' }}
                                                </strong>
                                                <span class="text-muted mr-2">({{ \App\Helpers\NumberToArabicWords::convert(abs($remaining)) }})</span>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                       
                    </div>

                    <hr>
                    
                    <div class="row mt-4 print-section">
                        <div class="col-md-4">
                            <p><strong>توقيع المحاسب</strong></p>

                        </div>
                        <div class="col-md-4">
                            <p><strong>توقيع مدير المستشفى</strong></p>
                        </div>
                      

                            <div class="signature-line"></div>
                        </div>
                        <div class="col-md-4">
                            <p><strong>توقيع مدير المستشفى</strong></p>
                            <div class="signature-line"></div>
                        </div>
                     
                    </div>

                    <div class="row mt-4">
                        <div class="col-12 text-center">
                            <button onclick="window.print()" class="btn btn-lg btn-dark mx-2 no-print shadow-sm"><i class="fas fa-print"></i> طباعة الفاتورة</button>
                            <a href="{{ route('private-wings.index') }}" class="btn btn-lg btn-secondary mx-2 no-print shadow-sm"><i class="fas fa-arrow-left"></i> رجوع</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('js')
<!-- Internal Data table js -->
<script src="{{ URL::asset('assets/plugins/datatable/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::asset('assets/plugins/datatable/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ URL::asset('assets/plugins/datatable/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ URL::asset('assets/plugins/datatable/js/responsive.bootstrap4.min.js') }}"></script>
<script>
    $(document).ready(function() {
        $('#services-table').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Arabic.json"
            },
            "order": [[ 0, "asc" ]], // ترتيب افتراضي حسب اسم الخدمة تصاعدياً
            "columnDefs": [
                { "orderable": false, "targets": 2 } // عدم ترتيب عمود احتساب الأيام إذا لزم الأمر
            ]
        });
        
        $('#receipts-table').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Arabic.json"
            },
            "order": [[ 3, "desc" ]], // ترتيب افتراضي حسب التاريخ تنازلياً
            "columnDefs": [
                { "orderable": false, "targets": 0 } // عدم ترتيب العمود الأول (#)
            ]
        });
    });
</script>
@endsection
