<?php

namespace App\Http\Controllers;

use App\Models\Service;
use App\Models\TypeSpecialization;
use App\Models\Service_Specialization;
use App\Models\PrivateWing;
use App\Models\PrivateWingService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class PrivateWingController extends Controller
{    function __construct()
    {
    $this->middleware('permission:اجنحة', ['only' => ['index','store','create','edit','update','destroy','invoice','getSpecializations','getInstitutions','getServicePrice','show','getSpecializations',
    'getInstitutions','getServicePrice','getSpecializations','getInstitutions','getServicePrice']]);
  
    
    } 
    public function invoice($wing)
    {
        $privateWing = PrivateWing::withTrashed()->with(['receipts'])->findOrFail($wing);

        // جلب الخدمات مباشرة من قاعدة البيانات باستخدام الاستعلام
        $services = DB::table('private_wing_services as pws')
            ->join('service_specialization as ss', 'pws.service_id', '=', 'ss.id')
            ->leftJoin('doctors as d', 'pws.doctor_id', '=', 'd.id')
            ->where('pws.private_wing_id', $privateWing->id)
            ->select(
                'ss.namesv as service_name',
                'd.name as doctor_name',
                'pws.service_fee',
                'pws.is_daily',
                'pws.total_amount',
                'pws.operation_degree'
            )
            ->orderBy('ss.namesv', 'asc')
            ->get();

        // حساب المجموع الكلي للخدمات
        $totalAmount = $services->sum('total_amount');

        return view('private-wings.invoice', compact('privateWing', 'services', 'totalAmount'));
    }

    public function index()
    {
        $privateWings = PrivateWing::orderBy('entry_date', 'desc')->paginate(10);
        return view('private-wings.index', compact('privateWings'));
    }    public function create()
    {
    $typeSpecializations = TypeSpecialization::all();
    $doctors = \App\Models\Doctor::all();
    // جلب آخر رقم قائمة حساب وزيادته واحد
    $lastWing = PrivateWing::orderByDesc('id')->first();
    $nextFileNumber = $lastWing ? ((int)$lastWing->file_number + 1) : 1;
    return view('private-wings.create', compact('typeSpecializations', 'nextFileNumber', 'doctors'));
    }    public function store(Request $request)
    {
        // للتأكد من البيانات المرسلة
        Log::info('Request data:', $request->all());

        $validated = $request->validate([
            'hospital' => 'required|string|max:255',
            'health_department' => 'required|string|max:255',
            'patient_name' => 'required|string|max:255',
            'patient_nationality' => 'nullable|string|max:255',
            'file_number' => 'required|string|max:255',
            'statistical_number' => 'required|string|max:255',
            'table_number' => 'nullable|string|max:255',
            'entry_date' => 'required|date',
            'exit_date' => 'nullable|date',
            'days_count' => 'required|integer',
            'is_insured' => 'required|in:0,1',
            'deposits' => 'required|array|min:1',
            'deposits.*.amount' => 'required|numeric|min:0',
            'deposits.*.number' => 'required|string|max:255',
            'deposits.*.date' => 'required|date',
            'deposits.*.payment_type' => 'required|in:كاش,إلكتروني',
            'deposits.*.interest_rate' => 'required|numeric|min:0|max:100',
            'deposits.*.interest_amount' => 'required|numeric|min:0',
            'services' => 'required|array',
            'services.*.id' => 'required|exists:service_specialization,id',
            'services.*.fee' => 'required|numeric',
            'services.*.is_daily' => 'required|boolean',
            'services.*.doctor_id' => 'nullable|exists:doctors,id',
            'services.*.operation_degree' => 'nullable|string|max:255'
        ]);

        try {
            DB::beginTransaction();

            // إنشاء سجل الجناح الخاص
            $privateWing = PrivateWing::create([
                'hospital' => $validated['hospital'],
                'health_department' => $validated['health_department'],
                'patient_name' => $validated['patient_name'],
                'patient_nationality' => $validated['patient_nationality'] ?? null,
                'file_number' => $validated['file_number'],
                'statistical_number' => $validated['statistical_number'],
                'table_number' => $validated['table_number'] ?? null,
                'entry_date' => $validated['entry_date'],
                'exit_date' => $validated['exit_date'],
                'days_count' => $validated['days_count'],
                'is_insured' => $validated['is_insured']
            ]);

            // إضافة وصولات التأمين
            $totalDeposits = 0;
            foreach ($validated['deposits'] as $deposit) {
                $privateWing->receipts()->create([
                    'amount' => $deposit['amount'],
                    'receipt_number' => $deposit['number'],
                    'receipt_date' => $deposit['date'],
                    'payment_type' => $deposit['payment_type'],
                    'interest_rate' => $deposit['interest_rate'],
                    'interest_amount' => $deposit['interest_amount']
                ]);
                $totalDeposits += $deposit['amount'] + $deposit['interest_amount'];
            }
            
            // تحديث إجمالي التأمينات في الجناح
            $privateWing->update([
                'deposit_amount' => $totalDeposits
            ]);
            $totalAmount = 0;
            // إضافة الخدمات وتسجيل المعلومات للتأكد من البيانات
            Log::info('Adding services:', $validated['services']);
            
            foreach ($validated['services'] as $service) {
                Log::info('Processing service:', $service);
                Log::info('doctor_id value:', ['value' => $service['doctor_id']]);
                Log::info('doctor_id type:', ['type' => gettype($service['doctor_id'])]);
                
                $serviceAmount = $service['is_daily'] ? 
                    $service['fee'] * $validated['days_count'] : 
                    $service['fee'];
                  try {
                    // تسجيل البيانات للتأكد من صحتها
                    Log::info('Creating service with data:', [
                        'private_wing_id' => $privateWing->id,
                        'service_id' => $service['id'],
                        'service_fee' => $service['fee'],
                        'is_daily' => $service['is_daily'],
                        'total_amount' => $serviceAmount
                    ]);                    
                    $doctorId = !empty($service['doctor_id']) && $service['doctor_id'] !== 'null' ? $service['doctor_id'] : null;
                    Log::info('doctor_id after processing:', ['processed' => $doctorId]);
                    
                    // إنشاء سجل الخدمة باستخدام DB facade
                    $result = DB::table('private_wing_services')->insert([
                        'private_wing_id' => $privateWing->id,
                        'service_id' => $service['id'],
                        'service_fee' => $service['fee'],
                        'is_daily' => $service['is_daily'],
                        'doctor_id' => $doctorId,
                        'total_amount' => $serviceAmount,
                        'operation_degree' => $service['operation_degree'] ?? null,
                        'created_at' => now(),
                        'updated_at' => now()
                    ]);
                    
                    Log::info('Service saved successfully:', ['result' => $result]);
                    
                    
                    $totalAmount += $serviceAmount;
                } catch (\Exception $e) {
                    Log::error('Error creating service: ' . $e->getMessage());
                    throw $e;
                }
            }

            // تحديث المبلغ الإجمالي
            $privateWing->update(['total_amount' => $totalAmount]);

            DB::commit();

            return redirect()->route('private-wings.index')
                ->with('success', 'تم إنشاء سجل الجناح الخاص بنجاح');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error saving private wing: ' . $e->getMessage());
            return back()->withErrors(['error' => $e->getMessage()])->withInput();
        }
    }

    public function show($id)
    {
        $privateWing = PrivateWing::withTrashed()->with(['receipts'])->findOrFail($id);
        // تحميل علاقة الوصولات مع الجناح الخاص
        $privateWing->load('receipts');
        
        // جلب الخدمات مباشرة من قاعدة البيانات باستخدام الاستعلام
        $services = DB::table('private_wing_services as pws')
            ->join('service_specialization as ss', 'pws.service_id', '=', 'ss.id')
            ->leftJoin('doctors as d', 'pws.doctor_id', '=', 'd.id')
            ->where('pws.private_wing_id', $privateWing->id)
            ->select(
                'ss.namesv as service_name',
                'd.name as doctor_name',
                'pws.service_fee',
                'pws.is_daily',
                'pws.total_amount',
                'pws.operation_degree'
            )
            ->orderBy('ss.namesv', 'asc')
            ->get();

        // حساب المجموع الكلي للخدمات
        $totalAmount = $services->sum('total_amount');

        return view('private-wings.show', compact('privateWing', 'services', 'totalAmount'));
    }    public function edit(PrivateWing $privateWing)
    {
        $privateWing->load('services');
        $typeSpecializations = TypeSpecialization::all();
        
        // جلب الخدمات مباشرة من قاعدة البيانات باستخدام الاستعلام
        $services = DB::table('private_wing_services as pws')
            ->join('service_specialization as ss', 'pws.service_id', '=', 'ss.id')
            ->leftJoin('doctors as d', 'pws.doctor_id', '=', 'd.id')
            ->where('pws.private_wing_id', $privateWing->id)
            ->select(
                'ss.id',
                'ss.namesv as service_name',
                'd.name as doctor_name',
                'pws.service_fee',
                'pws.is_daily',
                'pws.total_amount',
                'pws.operation_degree'
            )
            ->orderBy('ss.namesv', 'asc')
            ->get();
        
        return view('private-wings.edit', compact('privateWing','typeSpecializations', 'services'));
    }    public function update(Request $request, PrivateWing $privateWing)
    {
        try {
            DB::beginTransaction();

            $validated = $request->validate([
                'hospital' => 'required|string|max:255',
                'health_department' => 'required|string|max:255',
                'patient_name' => 'required|string|max:255',
                'patient_nationality' => 'nullable|string|max:255',
                'file_number' => 'required|string|max:255',
                'statistical_number' => 'required|string|max:255',
                'table_number' => 'nullable|string|max:255',
                'entry_date' => 'required|date',
                'exit_date' => 'nullable|date',
                'days_count' => 'required|integer',
                'is_insured' => 'nullable|in:1',
              
                'deposits' => 'required|array|min:1',
                'deposits.*.amount' => 'required|numeric|min:0',
                'deposits.*.number' => 'required|string|max:255',
                'deposits.*.date' => 'required|date',
                'deposits.*.payment_type' => 'required|in:كاش,إلكتروني',
                'deposits.*.interest_rate' => 'required|numeric|min:0|max:100',
                'deposits.*.interest_amount' => 'required|numeric|min:0',
                'services' => 'required|array',
                'services.*.id' => 'required|exists:service_specialization,id',
                'services.*.fee' => 'required|numeric',
                'services.*.is_daily' => 'required|boolean',
                'services.*.doctor_id' => 'nullable|exists:doctors,id',
                'services.*.operation_degree' => 'nullable|string|max:255'
            ]);

            // تحديث بيانات الجناح الخاص
            $privateWing->update([
                'hospital' => $validated['hospital'],
                'health_department' => $validated['health_department'],
                'patient_name' => $validated['patient_name'],
                'patient_nationality' => $validated['patient_nationality'] ?? null,
                'file_number' => $validated['file_number'],
                'statistical_number' => $validated['statistical_number'],
                'table_number' => $validated['table_number'] ?? null,
                'entry_date' => $validated['entry_date'],
                'exit_date' => $validated['exit_date'],
                'days_count' => $validated['days_count'],
                'is_insured' => $request->has('is_insured') ? 1 : 0,
               
            ]);

            // حذف جميع الوصولات القديمة
            $privateWing->receipts()->delete();

            // إضافة وصولات التأمين الجديدة
            $totalDeposits = 0;
            foreach ($validated['deposits'] as $deposit) {
                $privateWing->receipts()->create([
                    'amount' => $deposit['amount'],
                    'receipt_number' => $deposit['number'],
                    'receipt_date' => $deposit['date'],
                    'payment_type' => $deposit['payment_type'],
                    'interest_rate' => $deposit['interest_rate'],
                    'interest_amount' => $deposit['interest_amount']
                ]);
                $totalDeposits += $deposit['amount'] + $deposit['interest_amount'];
            }

            // تحديث إجمالي التأمينات في الجناح
            $privateWing->update([
                'deposit_amount' => $totalDeposits
            ]);

            // حذف الخدمات القديمة
            DB::table('private_wing_services')->where('private_wing_id', $privateWing->id)->delete();

            // إضافة الخدمات الجديدة وحساب المجموع
            $totalAmount = 0;
            foreach ($validated['services'] as $service) {
                Log::info('Processing service in update:', $service);
                Log::info('doctor_id value in update:', ['value' => $service['doctor_id']]);
                
                $serviceAmount = $service['is_daily'] ? 
                    $service['fee'] * $validated['days_count'] : 
                    $service['fee'];

                // استخدام السعر المدخل يدوياً
                $serviceFee = $service['fee'];
                $doctorId = !empty($service['doctor_id']) && $service['doctor_id'] !== 'null' ? $service['doctor_id'] : null;
                Log::info('doctor_id after processing in update:', ['processed' => $doctorId]);
                
                DB::table('private_wing_services')->insert([
                    'private_wing_id' => $privateWing->id,
                    'service_id' => $service['id'],
                    'service_fee' => $serviceFee,
                    'is_daily' => $service['is_daily'],
                    'doctor_id' => $doctorId,
                    'total_amount' => $serviceAmount,
                    'operation_degree' => $service['operation_degree'] ?? null,
                    'created_at' => now(),
                    'updated_at' => now()
                ]);

                $totalAmount += $serviceAmount;
            }

            // تحديث المبلغ الإجمالي
            $privateWing->update(['total_amount' => $totalAmount]);

            DB::commit();
            
            return redirect()->route('private-wings.index')
                ->with('success', 'تم تحديث سجل الجناح الخاص بنجاح');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error updating private wing: ' . $e->getMessage());
            return back()->withErrors(['error' => $e->getMessage()])->withInput();
        }
    }

    public function destroy(PrivateWing $privateWing)
    {
        $privateWing->delete();

        return redirect()->route('private-wings.index')
            ->with('success', 'تم حذف سجل الجناح الخاص بنجاح');
    } 
    public function getSpecializations(Request $request)
    {
        try {
            // التحقق من وجود section_id و fckt
            $section_id = $request->input('section_id');
          

            if (!$section_id) {
                return response()->json([], 400); // Bad Request إذا كانت البيانات غير مكتملة
            }

            // جلب المؤسسات بناءً على section_id و
            $institutions = Service::where('type_specializations_id', $section_id)
                ->get();

            return response()->json($institutions);
        } catch (\Exception $e) {
            // تسجيل الخطأ في السجلات
            \Log::error('Error fetching institutions: ' . $e->getMessage());
            return response()->json(['error' => 'Internal Server Error'], 500);
        }
    }
       public function getInstitutions(Request $request)
    {
        try {
            // التحقق من وجود section_id و fckt
            $section_id = $request->input('section_id');
            $fckn = $request->input('fckn');

            if (!$section_id || !$fckn) {
                return response()->json([], 400); // Bad Request إذا كانت البيانات غير مكتملة
            }

            // جلب المؤسسات بناءً على section_id و fckt
            $institution = service_specialization::where('type_specializations_id', $section_id)
                ->where('service_id', $fckn)
                ->get();

            return response()->json($institution);
        } catch (\Exception $e) {
            // تسجيل الخطأ في السجلات
            \Log::error('Error fetching institutions: ' . $e->getMessage());
            return response()->json(['error' => 'Internal Server Error'], 500);
        }
    }    public function getServicePrice(Request $request)
    {
        try {
            // لا نحتاج لجلب السعر من قاعدة البيانات - السعر سيكون دائماً صفر للسماح بالإدخال اليدوي
            return response()->json(['price' => 0]);
        } catch (\Exception $e) {
            Log::error('Error in getServicePrice: ' . $e->getMessage());
            return response()->json(['price' => 0]);
        }
    }

    // عرض السجلات المحذوفة مؤقتاً
    public function trashed()
    {
        $privateWings = PrivateWing::onlyTrashed()->orderBy('deleted_at', 'desc')->paginate(10);
        return view('private-wings.trashed', compact('privateWings'));
    }

    // حذف نهائي لسجل مريض
    public function forceDelete($id)
    {
        $privateWing = PrivateWing::withTrashed()->findOrFail($id);
        // حذف الوصولات والخدمات المرتبطة
        $privateWing->receipts()->delete();
        DB::table('private_wing_services')->where('private_wing_id', $privateWing->id)->delete();
        $privateWing->forceDelete();
        return redirect()->route('private-wings.trashed')->with('success', 'تم حذف السجل نهائياً');
    }

    // استعادة سجل مريض محذوف مؤقتاً
    public function restore($id)
    {
        $privateWing = PrivateWing::withTrashed()->findOrFail($id);
        $privateWing->restore();
        return redirect()->route('private-wings.trashed')->with('success', 'تم استعادة السجل بنجاح');
    }
}