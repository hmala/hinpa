<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PrivateWingService;
use App\Models\Service;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\OperationFeesExport;

class OperationFeesController extends Controller
{
    public function index(Request $request)
    {
        $month = $request->input('month');
        $year = $request->input('year');

        // Get operation fees grouped by operation degree
        $operationDegrees = ['الخاصة', 'فوق الكبرى', 'كبرى', 'متوسطة', 'صغرى'];

        $operationFeesByDegree = [];

        foreach ($operationDegrees as $degree) {
            $query = PrivateWingService::with(['service' => function($query) {
                $query->with('typeSpecialization');
            }])
            ->where('operation_degree', $degree)
            ->whereHas('service', function($query) {
                $query->where('namesv', 'like', '%عملية%')
                      ->orWhere('namesv', 'like', '%جراحة%')
                      ->orWhere('namesv', 'like', '%عمليات%');
            });

            // إضافة فلتر الشهر والسنة
            if ($month && $year) {
                $query->whereHas('privateWing', function($q) use ($month, $year) {
                    $q->whereMonth('entry_date', $month)
                      ->whereYear('entry_date', $year);
                });
            } elseif ($year) {
                $query->whereHas('privateWing', function($q) use ($year) {
                    $q->whereYear('entry_date', $year);
                });
            } elseif ($month) {
                $query->whereHas('privateWing', function($q) use ($month) {
                    $q->whereMonth('entry_date', $month);
                });
            }

            $operationFeesByDegree[$degree] = $query->selectRaw('service_id, service_fee, COUNT(*) as count, SUM(total_amount) as total_amount')
                ->groupBy('service_id', 'service_fee')
                ->get()
                ->keyBy('service_id');
        }

        // Get all unique services across all degrees
        $allServices = collect();
        foreach ($operationFeesByDegree as $degree => $fees) {
            $allServices = $allServices->merge($fees);
        }
        $uniqueServices = $allServices->unique('service_id')->sortBy(function($service) {
            return $service->service->namesv ?? '';
        });

        return view('operation-fees.index', compact('operationFeesByDegree', 'operationDegrees', 'uniqueServices', 'month', 'year'));
    }

    /**
     * تصدير بيانات رسوم العمليات إلى Excel
     */
    public function export(Request $request)
    {
        $month = $request->input('month');
        $year = $request->input('year');

        $fileName = 'operation_fees';
        if ($month && $year) {
            $fileName .= '_month_' . $month . '_year_' . $year;
        } elseif ($year) {
            $fileName .= '_year_' . $year;
        } elseif ($month) {
            $fileName .= '_month_' . $month;
        }
        $fileName .= '_' . date('Y-m-d_H-i-s') . '.xlsx';

        return Excel::download(new OperationFeesExport($month, $year), $fileName);
    }
}
