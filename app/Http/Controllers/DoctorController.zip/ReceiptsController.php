<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PrivateWingReceipt;
use App\Models\PrivateWing;

class ReceiptsController extends Controller
{
    public function index(Request $request)
    {
        $query = PrivateWingReceipt::with('privateWing');

        // فلترة حسب التاريخ إذا تم تحديده
        if ($request->filled('date_from')) {
            $query->where('receipt_date', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->where('receipt_date', '<=', $request->date_to);
        }

        // فلترة حسب رقم الوصل
        if ($request->filled('receipt_number')) {
            $query->where('receipt_number', 'like', '%' . $request->receipt_number . '%');
        }

        $receipts = $query->orderBy('receipt_date', 'desc')
                          ->orderBy('created_at', 'desc')
                          ->paginate(15);

        return view('receipts.index', compact('receipts'));
    }

    public function show($id)
    {
        $receipt = PrivateWingReceipt::with('privateWing')->findOrFail($id);

        return view('receipts.show', compact('receipt'));
    }
}