<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PrivateWing;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\PrivateWingDetailsExport;

class PrivateWingDetailsController extends Controller
{
    /**
     * عرض تفاصيل الأجنحة الخاصة
     */
    public function index()
    {
        $privateWings = PrivateWing::with(['receipts', 'privateWingServices.service', 'privateWingServices.doctor', 'privateWingServices.service.typeSpecialization'])
            ->select([
                'id',
                'patient_name',
                'file_number',
                'deposit_amount',
                'total_amount',
                'entry_date',
                'exit_date',
                'days_count',
                'is_insured'
            ])
            ->orderBy('created_at', 'desc')
            ->get();

        // جلب الخدمات المستخدمة في الأجنحة الخاصة
        $usedServices = \App\Models\PrivateWingService::with('service')
            ->whereHas('privateWing')
            ->select('service_id')
            ->distinct()
            ->get()
            ->pluck('service.namesv', 'service_id')
            ->filter()
            ->sort();

        return view('private-wing-details.index', compact('privateWings', 'usedServices'));
    }

    /**
     * تصدير تفاصيل الأجنحة الخاصة إلى Excel
     */
    public function export()
    {
        return Excel::download(new PrivateWingDetailsExport, 'private_wing_details_' . date('Y-m-d') . '.xlsx');
    }
}